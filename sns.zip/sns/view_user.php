<?php
require 'config.php';
$collection = getUsersCollection();

$id = new MongoDB\BSON\ObjectId($_GET['id']);
$user = $collection->findOne(['_id' => $id]);

if (!$user) {
    render_header('User not found');
    echo "<h2>User not found</h2>";
    render_footer();
    exit;
}

// 값 꺼내기 + BSONArray → PHP array 변환
$username = $user['username'] ?? '(no name)';
$age      = $user['age'] ?? '(unknown)';
$hobbies  = isset($user['hobbies'])   ? $user['hobbies']->getArrayCopy()   : [];
$friends  = isset($user['friends'])   ? $user['friends']->getArrayCopy()   : [];
$logs     = isset($user['recentLogs'])? $user['recentLogs']->getArrayCopy(): [];

render_header($username . ' Profile');
?>

<h2 class="mb-3"><?= htmlspecialchars($username, ENT_QUOTES, 'UTF-8') ?> Profile</h2>
<p><strong>Age:</strong> <?= htmlspecialchars($age, ENT_QUOTES, 'UTF-8') ?></p>

<hr>

<h4>Hobbies</h4>
<?php if (!empty($hobbies)): ?>
  <p><?= htmlspecialchars(implode(', ', $hobbies), ENT_QUOTES, 'UTF-8') ?></p>
<?php else: ?>
  <p class="text-muted">No hobbies stored.</p>
<?php endif; ?>

<hr>

<h4>Friends</h4>
<?php if (!empty($friends)): ?>
  <ul>
    <?php foreach ($friends as $f): ?>
      <li><?= htmlspecialchars($f, ENT_QUOTES, 'UTF-8') ?></li>
    <?php endforeach; ?>
  </ul>
<?php else: ?>
  <p class="text-muted">No friends yet.</p>
<?php endif; ?>

<form method="post" action="add_friend.php" class="row g-2 mb-3">
  <input type="hidden" name="id" value="<?= htmlspecialchars((string)$user['_id'], ENT_QUOTES, 'UTF-8') ?>">
  <div class="col-auto">
    <input name="friend" class="form-control" placeholder="New friend name" required>
  </div>
  <div class="col-auto">
    <button class="btn btn-outline-primary">Add Friend</button>
  </div>
</form>

<hr>

<h4>Recent Logs</h4>
<?php if (!empty($logs)): ?>
  <ul>
    <?php foreach ($logs as $log):
      $action = $log['action'] ?? 'unknown';
      $time   = $log['time'] ?? 'unknown';
    ?>
      <li><?= htmlspecialchars($action, ENT_QUOTES, 'UTF-8') ?>
          <span class="text-muted">(<?= htmlspecialchars($time, ENT_QUOTES, 'UTF-8') ?>)</span></li>
    <?php endforeach; ?>
  </ul>
<?php else: ?>
  <p class="text-muted">No recent logs.</p>
<?php endif; ?>

<form method="post" action="add_log.php" class="row g-2 mb-3">
  <input type="hidden" name="id" value="<?= htmlspecialchars((string)$user['_id'], ENT_QUOTES, 'UTF-8') ?>">
  <div class="col-auto">
    <input name="action" class="form-control" placeholder="Action description" required>
  </div>
  <div class="col-auto">
    <button class="btn btn-outline-primary">Add Log</button>
  </div>
</form>

<a href="list_users.php" class="btn btn-link">Back to list</a>

<?php render_footer(); ?>

