<?php
require 'config.php';
$collection = getUsersCollection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idStr  = $_POST['id'] ?? '';
    $action = trim($_POST['action'] ?? '');

    if ($idStr !== '' && $action !== '') {
        $id = new MongoDB\BSON\ObjectId($idStr);

        $collection->updateOne(
            ['_id' => $id],
            ['$push' => [
                'recentLogs' => [
                    'action' => $action,
                    'time'   => date('Y-m-d H:i:s'),
                ]
            ]]
        );
    }

    header('Location: view_user.php?id=' . urlencode($idStr));
    exit;
}

