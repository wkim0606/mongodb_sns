<?php
require 'config.php';
$collection = getUsersCollection();

// 기존 데이터 삭제(선택)
$collection->drop();

$names   = ['wboan01','wboan02','wboan03','wboan04','wboan05','wboan06','wboan07','wboan08','wboan09','wboan10'];
$hobbyPool = ['run','read','music','coding','game','travel','cook'];

$docs = [];
foreach ($names as $i => $name) {
    shuffle($hobbyPool);
    $docs[] = [
        'username'   => $name,
        'age'        => rand(15, 60),
        'hobbies'    => array_slice($hobbyPool, 0, rand(1,3)),
        'friends'    => [],
        'recentLogs' => []
    ];
}

$collection->insertMany($docs);

echo "Inserted " . count($docs) . " sample users into '" . MONGO_DB . "." . MONGO_COLL . "'";

