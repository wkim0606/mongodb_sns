<?php
require 'config.php';
$collection = getUsersCollection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $age      = (int)($_POST['age'] ?? 0);
    $hobbiesStr = trim($_POST['hobbies'] ?? '');

    // 간단한 검증
    $errors = [];
    if ($username === '') $errors[] = 'Username은 필수입니다.';
    if ($age <= 0)        $errors[] = 'Age는 1 이상의 정수를 입력하세요.';

    // username 중복 방지 (강의 포인트)
    if ($username !== '') {
        $existing = $collection->findOne(['username' => $username]);
        if ($existing) $errors[] = '이미 존재하는 Username 입니다.';
    }

    // 에러 없으면 MongoDB에 저장
    if (empty($errors)) {
        $hobbies = $hobbiesStr === ''
            ? []
            : array_values(array_filter(array_map('trim', explode(',', $hobbiesStr))));

        $collection->insertOne([
            'username'   => $username,
            'age'        => $age,
            'hobbies'    => $hobbies,
            'friends'    => [],          // 기본 빈 배열
            'recentLogs' => []           // 기본 빈 배열 (임베디드 문서 배열)
        ]);

        // 생성 후 목록으로 리다이렉트
        header('Location: list_users.php');
        exit;
    }
}

render_header('Create User');
?>

<h2 class="mb-3">Create User</h2>

<?php if (!empty($errors)): ?>
<div class="alert alert-danger">
  <ul class="mb-0">
    <?php foreach ($errors as $e): ?>
      <li><?= htmlspecialchars($e, ENT_QUOTES, 'UTF-8') ?></li>
    <?php endforeach; ?>
  </ul>
</div>
<?php endif; ?>

<form method="post" class="mt-3">
  <div class="mb-3">
    <label class="form-label">Username</label>
    <input type="text" name="username" class="form-control" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Age</label>
    <input type="number" name="age" class="form-control" min="1" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Hobbies (comma separated)</label>
    <input type="text" name="hobbies" class="form-control" placeholder="run, music, coding">
  </div>
  <button type="submit" class="btn btn-primary">Create</button>
  <a href="list_users.php" class="btn btn-secondary ms-2">Cancel</a>
</form>

<?php render_footer(); ?>

