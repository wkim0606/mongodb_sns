<?php
require 'config.php';
$collection = getUsersCollection();

$idStr = $_GET['id'] ?? '';
if ($idStr !== '') {
    $id = new MongoDB\BSON\ObjectId($idStr);
    $collection->deleteOne(['_id' => $id]);
}

header('Location: list_users.php');
exit;

