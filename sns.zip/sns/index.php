<?php
require 'config.php';
render_header('MongoDB SNS Demo - Home');
?>

<h1 class="mb-4">SNS 사용자 프로필 데모</h1>
<p>이 데모는 <strong>MongoDB 문서 모델링</strong>과 <strong>PHP(8.3) 연동</strong>을 보여주기 위한 예제입니다.</p>

<ul>
  <li>유저 정보(문서)</li>
  <li>hobbies: 배열</li>
  <li>friends: 배열</li>
  <li>recentLogs: 임베디드 문서 배열</li>
</ul>

<div class="mt-4">
  <a href="create_user.php" class="btn btn-primary me-2">Create New User</a>
  <a href="list_users.php" class="btn btn-outline-primary">User List</a>
</div>

<?php render_footer(); ?>

