<?php
// config.php
require __DIR__ . '/vendor/autoload.php';

const MONGO_DSN  = 'mongodb://192.168.20.50:27017'; // Windows MongoDB IP
const MONGO_DB   = 'snsdb';
const MONGO_COLL = 'users';

function getUsersCollection(): MongoDB\Collection {
    static $collection = null;
    if ($collection === null) {
        $client = new MongoDB\Client(MONGO_DSN);
        $db = $client->selectDatabase(MONGO_DB);
        $collection = $db->selectCollection(MONGO_COLL);
    }
    return $collection;
}

/** 공통 HTML 헤더 (Bootstrap + 기본 스타일) */
function render_header(string $title = 'SNS Demo') {
    echo <<<HTML
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>{$title}</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { padding-top: 60px; }
    .navbar-brand { font-weight: 600; }
    .container-narrow { max-width: 720px; }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">MongoDB SNS Demo</a>
    <div>
      <a class="btn btn-sm btn-light me-2" href="list_users.php">User List</a>
      <a class="btn btn-sm btn-outline-light" href="create_user.php">Create User</a>
    </div>
  </div>
</nav>
<div class="container container-narrow mt-4">
HTML;
}

/** 공통 HTML 푸터 */
function render_footer() {
    echo <<<HTML
</div>
</body>
</html>
HTML;
}

