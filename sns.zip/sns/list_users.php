<?php
require 'config.php';
$collection = getUsersCollection();

// username 순으로 정렬
$cursor = $collection->find([], ['sort' => ['username' => 1]]);
$users  = iterator_to_array($cursor);

render_header('User List');
?>

<h2 class="mb-3">User List</h2>

<a href="create_user.php" class="btn btn-primary mb-3">+ Create User</a>

<?php if (empty($users)): ?>
  <p>등록된 사용자가 없습니다.</p>
<?php else: ?>
<table class="table table-striped">
  <thead>
    <tr>
      <th>Username</th>
      <th>Age</th>
      <th>Hobbies</th>
      <th style="width: 160px;">Actions</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach ($users as $u): ?>
    <?php
      $id = (string)$u['_id'];
      $hobbies = isset($u['hobbies'])
          ? implode(', ', (array)$u['hobbies']->getArrayCopy())
          : '';
    ?>
    <tr>
      <td><?= htmlspecialchars($u['username'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
      <td><?= htmlspecialchars($u['age'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
      <td><?= htmlspecialchars($hobbies, ENT_QUOTES, 'UTF-8') ?></td>
      <td>
        <a href="view_user.php?id=<?= $id ?>" class="btn btn-sm btn-outline-primary">View</a>
        <a href="delete_user.php?id=<?= $id ?>"
           class="btn btn-sm btn-outline-danger"
           onclick="return confirm('정말 삭제하시겠습니까?');">Delete</a>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php endif; ?>

<?php render_footer(); ?>

