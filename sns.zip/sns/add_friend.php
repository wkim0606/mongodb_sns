<?php
require 'config.php';
$collection = getUsersCollection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idStr  = $_POST['id'] ?? '';
    $friend = trim($_POST['friend'] ?? '');

    if ($idStr !== '' && $friend !== '') {
        $id = new MongoDB\BSON\ObjectId($idStr);

        $collection->updateOne(
            ['_id' => $id],
            ['$push' => ['friends' => $friend]]
        );
    }

    header('Location: view_user.php?id=' . urlencode($idStr));
    exit;
}

